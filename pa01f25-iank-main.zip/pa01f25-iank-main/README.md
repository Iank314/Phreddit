[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/vS16JFW6)

# Homework 1 -- Phreddit (Phake Reddit with HTML/CSS/JavaScript )

**Remember to list your contribution in the sections shown below before the due date.**

## Team Member 1 contribution

Zaber Jamal - 115458420

- Created Community and Comment object && Text for Banner 02/17/2025
- ~~Developed most of the homepage still has some bugs 02/19/2025~~
- Homepage finished no bugs fixed sortby Active 02/19/2025
- Search mostly works // have to add comment search functionality. Sortby and formatting is complete 02/19/2025
- Search comment finally complete took so long 02/20/2025
- Finished New Post Page View // works with create community and creates new flair. No issues 02/20/2025
- Completely finished New Comment Page (similar to new post page) 02/22/2025
- Overall finished Banner, Home Page View, Search Result View, New Post Page, New Comment Page
- Fixed Scrollbar, Home logo redirect, and Search Result 02/23/2025 Done!

## Team Member 2 contribution

Ian Kaufman - 115639955

- Created Post and LinkFlair classes 02/17/2025
- Developed NavBar 02/18/2025
- Developed Timestamp 02/19/2025
- Developed all create community features and created communities 02/20/2025
- Developed CommunityView completely 02/21/2025
- Completely Developed all features for the post comment stuff 02/22/2025
- Completely fixed all css for Post, Community, and general features 02/23/2025 Done!
